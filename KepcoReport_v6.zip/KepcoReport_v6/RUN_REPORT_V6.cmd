@echo off
echo KEPCO REPORT V6 - NAVER DUBAI FUTURES
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Capture.ps1" -Financial -Report
pause
