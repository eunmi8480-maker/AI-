function parseQuote(kind,text){
 const t=text.replace(/\u2212/g,'-').replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ');
 const number='[0-9][0-9,]*(?:\\.[0-9]+)?';
 let price, change, direction, block=t;
 if(kind==='us'){
  if(!/KEP\s*:\s*NYSE/i.test(t))throw Error('KEP:NYSE 종목 확인 실패');
  const start=t.search(/Korea Electric Power|한국전력공사/);if(start<0)throw Error('회사명 확인 실패');
  block=t.slice(start,start+1800);
  // First quote is the regular-session quote. Never select the after-hours quote.
  const m=block.match(new RegExp('\\$('+number+')\\s*(?:USD)?\\s*(arrow_(?:upward|downward))?\\s*([+-]?'+number+')%'));
  if(!m)throw Error('정규장 가격·등락률을 구분하지 못했습니다');
  price=m[1];change=m[3];direction=Number(change.replace(/,/g,''))===0?'flat':(m[2]==='arrow_downward'||change.startsWith('-')?'down':'up');
 }else{
  if(kind==='domestic'&&!/한국전력/.test(t))throw Error('한국전력 종목 확인 실패');
  if(kind==='fx'&&!/미국|USD|달러/.test(t))throw Error('미국 달러 확인 실패');
  const start=kind==='domestic'?t.search(/015760|한국전력/):t.search(/미국\s*(?:USD|달러)|USD\/KRW|미국 달러|달러\/원/);
  if(start<0)throw Error('대상 항목을 찾지 못했습니다');
  block=t.slice(start,start+1500);
  // Only accept an explicit quote + direction + absolute change, never a percentage.
  const patterns=[
   new RegExp('('+number+')\\s*(?:원|KRW)?\\s*(?:전일\\s*(?:대비|비)\\s*)?(상승|하락|보합|▲|▼|△|▽)\\s*('+number+')(?![0-9.,%])'),
   new RegExp('('+number+')\\s*(?:원|KRW)?\\s*(?:전일\\s*(?:대비|비)\\s*)?([+-])('+number+')(?![0-9.,%])')
  ];
  let m;for(const re of patterns){m=block.match(re);if(m)break;}
  if(!m)throw Error('가격·전일 대비 금액을 명확히 구분하지 못했습니다');
  price=m[1];change=m[3];direction=Number(change.replace(/,/g,''))===0?'flat':(/하락|▼|▽|-/.test(m[2])?'down':'up');
 }
 const v=Number(price.replace(/,/g,'')),c=Math.abs(Number(change.replace(/,/g,'')));
 if(!(v>0)||!Number.isFinite(c))throw Error('숫자 검증 실패');
 if(kind==='us'&&v>10000||kind==='fx'&&(v<100||v>10000)||kind==='domestic'&&(v<100||v>10000000))throw Error('값 범위 확인 필요');
 const sourceTime=(block.match(/(?:\d{2,4}[.\/-]\s*)?\d{1,2}[.\/-]\s*\d{1,2}[. ]*\s*\d{1,2}:\d{2}(?::\d{2})?\s*기준|Closed:[^\n]{0,120}/g)||[]).slice(0,2).join(' / ');
 return {ok:true,price:v,priceText:price,change:c,changeText:change.replace(/^[+-]/,''),direction,changeUnit:kind==='us'?'%':'원',currency:kind==='us'?'USD':'KRW',sourceTimeText:sourceTime||'페이지 기준 시각 확인 필요',evidence:block.slice(0,1700)};
}
function collectQuote(kind){
 const text=document.body?.innerText||'';
 const hosts={domestic:'search.daum.net',us:'www.google.com',fx:'stock.naver.com'};
 if(location.hostname!==hosts[kind]&&!(kind==='fx'&&location.hostname==='finance.naver.com'))return {ok:false,reason:'예상한 출처가 아닙니다',source:location.href};
 try{return {...parseQuote(kind,text),source:location.href,pageTitle:document.title};}
 catch(e){return {ok:false,reason:e.message,source:location.href,pageTitle:document.title,evidence:text.slice(0,16000)};}
}
