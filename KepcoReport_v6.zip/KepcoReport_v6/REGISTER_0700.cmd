@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Register0700.ps1"
pause
