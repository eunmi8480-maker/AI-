(() => {
 const normalize=s=>String(s||'').replace(/\s+/g,' ').trim();
 const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>8&&r.height>8&&s.visibility!=='hidden'&&s.display!=='none'};
 const all=[...document.querySelectorAll('body *')];
 const body=normalize(document.body?.innerText||'');
 if(/로봇이 아닙니다|자동입력 방지|비정상적인 접근|verify you are human|access denied|checking your browser/i.test(body))return {ok:false,reason:'접근 확인 또는 차단 화면이 표시됩니다. 자동화를 중단합니다.',pageTitle:document.title,pageUrl:location.href};
 function find(name){
  const exact=new RegExp('^(?:한국\\s*)?'+name+'(?:\\s*지수)?$');
  const labels=all.filter(e=>visible(e)&&exact.test(normalize(e.textContent))&&![...e.children].some(c=>exact.test(normalize(c.textContent))));
  const candidates=[];
  for(const label of labels){let e=label;for(let depth=0;e&&depth<9;depth++,e=e.parentElement){
   if(e===document.body)break;const r=e.getBoundingClientRect(),text=normalize(e.innerText||'');
   if(r.width<100||r.height<38||r.width>950||r.height>440||text.length>800)continue;
   if(!/\d[\d,]*\.\d+/.test(text))continue;
   if(!(text.includes('%')||/대비|상승|하락|보합|[▲▼△▽]/.test(text)))continue;
   if(text.includes(name==='코스피'?'코스닥':'코스피'))continue;
   const score=r.width*r.height*(1+(text.length>250?.5:0));
   candidates.push({name,text,score,node:e,label});
  }}
  candidates.sort((a,b)=>a.score-b.score);
  for(const best of candidates){
   const card=best.node.getBoundingClientRect(),labelRect=best.label.getBoundingClientRect();
   const descendants=all.filter(e=>best.node.contains(e)&&visible(e));
   // Quote nodes must be in the header, never chart axes or the time below the chart.
   const numbers=descendants.filter(e=>{
    const r=e.getBoundingClientRect(),t=normalize(e.textContent);
    return /\d[\d,]*\.\d+/.test(t)&&r.height<=55&&r.top>=labelRect.top-3&&r.top<=labelRect.bottom+60&&r.bottom<=labelRect.bottom+85;
   });
   if(!numbers.length)continue;
   const top=Math.max(card.top,labelRect.top-4);
   let bottom=Math.max(labelRect.bottom,...numbers.map(e=>e.getBoundingClientRect().bottom))+5;
   const tabs=descendants.filter(e=>/^(1일|1개월|3개월|1년|3년)$/.test(normalize(e.textContent))).map(e=>e.getBoundingClientRect()).filter(r=>r.top>labelRect.bottom);
   if(tabs.length)bottom=Math.min(bottom,Math.min(...tabs.map(r=>r.top))-5);
   if(bottom-top<30||bottom-top>125)continue;
   if(numbers.some(e=>e.getBoundingClientRect().bottom>bottom))continue;
   return {name,text:best.text.replace(/\s+1일[\s\S]*$/,''),score:best.score,x:card.left+scrollX,y:top+scrollY,width:Math.ceil(card.width),height:Math.ceil(bottom-top),cropMode:'index_and_change_only'};
  }
  return null;
 }
 const kospi=find('코스피'),kosdaq=find('코스닥');
 if(!kospi||!kosdaq)return {ok:false,reason:'지수·등락 정보가 함께 있는 코스피/코스닥 영역을 자동으로 찾지 못했습니다.',found:{kospi,kosdaq},pageTitle:document.title,pageUrl:location.href,readyState:document.readyState};
 const ratio=Math.max(kospi.height,kosdaq.height)/Math.min(kospi.height,kosdaq.height);
 const sameRow=Math.abs(kospi.y-kosdaq.y)<Math.max(kospi.height,kosdaq.height)*.6&&ratio<2.5;
 const x=Math.max(0,Math.min(kospi.x,kosdaq.x)),y=Math.max(0,Math.min(kospi.y,kosdaq.y));
 const union={x,y,width:Math.ceil(Math.max(kospi.x+kospi.width,kosdaq.x+kosdaq.width)-x),height:Math.ceil(Math.max(kospi.y+kospi.height,kosdaq.y+kosdaq.height)-y)};
 return {ok:true,kospi,kosdaq,union,sameRow,pageTitle:document.title,pageUrl:location.href,viewport:{width:innerWidth,height:innerHeight},observedAt:new Date().toISOString()};
})()
