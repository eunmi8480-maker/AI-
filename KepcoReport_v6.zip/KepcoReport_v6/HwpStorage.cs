using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
[ComImport, Guid("0000000b-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface KepcoIStorage {
 void CreateStream([MarshalAs(UnmanagedType.LPWStr)]string n,uint m,uint r1,uint r2,out IStream s);
 void OpenStream([MarshalAs(UnmanagedType.LPWStr)]string n,IntPtr r1,uint m,uint r2,out IStream s);
 void CreateStorage([MarshalAs(UnmanagedType.LPWStr)]string n,uint m,uint r1,uint r2,out KepcoIStorage s);
 void OpenStorage([MarshalAs(UnmanagedType.LPWStr)]string n,KepcoIStorage p,uint m,IntPtr e,uint r,out KepcoIStorage s);
 void CopyTo(uint n,IntPtr i,IntPtr e,KepcoIStorage d);
 void MoveElementTo([MarshalAs(UnmanagedType.LPWStr)]string n,KepcoIStorage d,[MarshalAs(UnmanagedType.LPWStr)]string nn,uint f);
 void Commit(uint f); void Revert();
 void EnumElements(uint r1,IntPtr r2,uint r3,out IntPtr e);
 void DestroyElement([MarshalAs(UnmanagedType.LPWStr)]string n);
 void RenameElement([MarshalAs(UnmanagedType.LPWStr)]string o,[MarshalAs(UnmanagedType.LPWStr)]string n);
 void SetElementTimes([MarshalAs(UnmanagedType.LPWStr)]string n,IntPtr c,IntPtr a,IntPtr m);
 void SetClass(ref Guid c);void SetStateBits(uint s,uint m);void Stat(out System.Runtime.InteropServices.ComTypes.STATSTG s,uint f);
}
public sealed class KepcoHwpStorage : IDisposable {
 [DllImport("ole32.dll",CharSet=CharSet.Unicode,PreserveSig=false)]
 static extern void StgOpenStorage(string n,KepcoIStorage p,uint m,IntPtr e,uint r,out KepcoIStorage s);
 KepcoIStorage root;
 public KepcoHwpStorage(string path){StgOpenStorage(path,null,18,IntPtr.Zero,0,out root);}
 KepcoIStorage Parent(string path,out string leaf){
  string[] parts=path.Split('/');leaf=parts[parts.Length-1];KepcoIStorage cur=root;
  for(int i=0;i<parts.Length-1;i++){KepcoIStorage next;cur.OpenStorage(parts[i],null,18,IntPtr.Zero,0,out next);if(cur!=root)Marshal.ReleaseComObject(cur);cur=next;}
  return cur;
 }
 public byte[] Read(string path){
  string leaf;KepcoIStorage parent=Parent(path,out leaf);IStream s=null;IntPtr count=Marshal.AllocHGlobal(4);
  try{parent.OpenStream(leaf,IntPtr.Zero,18,0,out s);System.Runtime.InteropServices.ComTypes.STATSTG stat;s.Stat(out stat,1);if(stat.cbSize>16777216)throw new IOException("Stream too large");byte[] b=new byte[(int)stat.cbSize];s.Read(b,b.Length,count);if(Marshal.ReadInt32(count)!=b.Length)throw new IOException("Short read");return b;}
  finally{Marshal.FreeHGlobal(count);if(s!=null)Marshal.ReleaseComObject(s);if(parent!=root)Marshal.ReleaseComObject(parent);}
 }
 public void Write(string path,byte[] bytes){
  string leaf;KepcoIStorage parent=Parent(path,out leaf);IStream s=null;IntPtr count=Marshal.AllocHGlobal(4);
  try{parent.OpenStream(leaf,IntPtr.Zero,18,0,out s);s.SetSize(bytes.Length);s.Seek(0,0,IntPtr.Zero);s.Write(bytes,bytes.Length,count);if(Marshal.ReadInt32(count)!=bytes.Length)throw new IOException("Short write");s.Commit(0);}
  finally{Marshal.FreeHGlobal(count);if(s!=null)Marshal.ReleaseComObject(s);if(parent!=root)Marshal.ReleaseComObject(parent);}
 }
 public void RemovePreview(){try{root.DestroyElement("PrvImage");}catch(COMException){}}
 public void Commit(){root.Commit(0);}
 public void Dispose(){if(root!=null){Marshal.ReleaseComObject(root);root=null;}}
}
