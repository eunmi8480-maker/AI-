﻿function Read-KepcoNaverFx {
 param([string]$OutputFolder)
 $apiUrl='https://api.stock.naver.com/marketindex/exchange/FX_USDKRW'
 $savedProtocol=[Net.ServicePointManager]::SecurityProtocol
 try{
  [Net.ServicePointManager]::SecurityProtocol=$savedProtocol -bor [Net.SecurityProtocolType]::Tls12
  $response=Invoke-WebRequest -Uri $apiUrl -UseBasicParsing -TimeoutSec 20 -Headers @{Accept='application/json';Referer='https://stock.naver.com/'}
  $raw=[string]$response.Content
  # Preserve the exact source response for comparison; do not read historical prices.
  [IO.File]::WriteAllText((Join-Path $OutputFolder 'fx_네이버원본.json'),$raw,[Text.UTF8Encoding]::new($true))
  $data=$raw|ConvertFrom-Json
  $fx=$data.exchangeInfo
  if(!$fx -or $fx.reutersCode -ne 'FX_USDKRW' -or $fx.categoryType -ne 'exchange' -or $fx.symbolCode -ne 'USD' -or $fx.unit -ne 'KRW'){throw '네이버 USD/KRW 응답 항목 검증 실패'}
  $invariant=[Globalization.CultureInfo]::InvariantCulture
  $priceText=[string]$fx.closePrice;$changeText=[string]$fx.fluctuations
  if($priceText -notmatch '^\d{1,3}(?:,\d{3})*(?:\.\d+)?$|^\d+(?:\.\d+)?$' -or $changeText -notmatch '^[+-]?\d[\d,]*(?:\.\d+)?$'){throw '환율 숫자 형식 검증 실패'}
  $price=[double]::Parse($priceText.Replace(',',''),$invariant)
  $signedChange=[double]::Parse($changeText.Replace(',',''),$invariant)
  if($price -lt 100 -or $price -gt 10000){throw 'USD/KRW 환율 범위 확인 필요'}
  $direction=if($signedChange -gt 0){'up'}elseif($signedChange -lt 0){'down'}else{'flat'}
  $trend=[string]$fx.fluctuationsType.name
  if(($trend -eq 'RISING' -and $signedChange -le 0) -or ($trend -eq 'FALLING' -and $signedChange -ge 0)){throw '환율 등락 방향과 금액 불일치'}
  $sourceTime=[datetimeoffset]::Parse([string]$fx.localTradedAt,$invariant)
  if($sourceTime.UtcDateTime -gt [datetime]::UtcNow.AddMinutes(2)){throw '네이버 기준 시각이 현재보다 미래입니다'}
  return [pscustomobject]@{ok=$true;price=$price;priceText=$priceText;change=[Math]::Abs($signedChange);changeText=$changeText.TrimStart([char[]]'+-');direction=$direction;changeUnit='원';currency='KRW';source=$apiUrl;pageTitle='네이버 USD/KRW 매매기준율';sourceTimeText=([string]$fx.localTradedAt+' / '+[string]$fx.stockExchangeType.nameKor+' / 고시 '+[string]$fx.degreeCount+'회');evidence=($fx|ConvertTo-Json -Depth 12);sourceResponseFile='fx_네이버원본.json'}
 }finally{[Net.ServicePointManager]::SecurityProtocol=$savedProtocol}
}
