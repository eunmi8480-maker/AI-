﻿# Uses the isolated Edge session and CDP functions from Capture.ps1.
$financeJs=[IO.File]::ReadAllText((Join-Path $root 'finance.js'),[Text.Encoding]::UTF8)
$items=@(
 @{key='domestic';label='한국전력 국내';url='https://search.daum.net/search?w=tot&q=kepco%20%EC%A3%BC%EA%B0%80'},
 @{key='us';label='한국전력 미국';url='https://www.google.com/finance/quote/KEP:NYSE?hl=en'},
 @{key='fx';label='미국 달러 환율';url='https://stock.naver.com/marketindex/exchange/FX_USDKRW/price'}
)
. (Join-Path $root 'ReadNaverFx.ps1')
. (Join-Path $root 'ReadGoogleUs.ps1')
$rows=@();$allOk=$true
foreach($item in $items){
 Log ('수집 시작: '+$item.label)
 $quote=$null
 if($item.key -eq 'fx'){
  try{$quote=Read-KepcoNaverFx -OutputFolder $folder}
  catch{$quote=[pscustomobject]@{ok=$false;reason=$_.Exception.Message;source='https://api.stock.naver.com/marketindex/exchange/FX_USDKRW'}}
 }
 if($item.key -eq 'us'){
  try{$quote=Read-KepcoGoogleUs -OutputFolder $folder}
  catch{$quote=[pscustomobject]@{ok=$false;reason=$_.Exception.Message;source=$item.url}}
 }
 for($attempt=1;$item.key -eq 'domestic' -and $attempt -le 2;$attempt++){
  try{
   # Retry on a new isolated tab, never on a personal browser session.
   if($attempt -gt 1 -or !$socket -or $socket.State -ne [Net.WebSockets.WebSocketState]::Open){
    Log ($item.label+': 전용 새 탭에서 연결 재시도')
    if($socket){$socket.Dispose()}
    $target=Invoke-RestMethod -Method Put -Uri ('http://127.0.0.1:'+$port+'/json/new?about:blank') -TimeoutSec 10
    $socket=[Net.WebSockets.ClientWebSocket]::new();$socket.Options.Proxy=$null
    $cts=[Threading.CancellationTokenSource]::new(10000)
    try{[void]$socket.ConnectAsync([uri]$target.webSocketDebuggerUrl,$cts.Token).GetAwaiter().GetResult()}finally{$cts.Dispose()}
    [void](CDP 'Page.enable');[void](CDP 'Runtime.enable')
    [void](CDP 'Emulation.setDeviceMetricsOverride' @{width=1440;height=1000;deviceScaleFactor=1;mobile=$false})
   }
   $quote=$null
   $nav=CDP 'Page.navigate' @{url=$item.url};if($nav.errorText){throw $nav.errorText}
   $until=[datetime]::UtcNow.AddSeconds(30)
   do{
    Start-Sleep -Milliseconds 800
    $ready=Eval ('location.href !== "about:blank" && document.readyState === "complete" && '+ '(location.hostname === "'+([uri]$item.url).Host+'")')
    if($ready){$quote=Eval ($financeJs+"`ncollectQuote('"+$item.key+"')");if($quote.ok){break}}
   }while([datetime]::UtcNow -lt $until)
   if(!$quote){throw '페이지를 읽지 못했습니다'}
   if($quote.ok){Start-Sleep -Milliseconds 700;$next=Eval ($financeJs+"`ncollectQuote('"+$item.key+"')");if(!$next.ok){throw '확인 중 값이 사라졌습니다'};$quote=$next}
   # Failure to save a screenshot must not discard an already-read quote.
   try{Capture (Join-Path $folder ($item.key+'_원본화면.png')) $null}
   catch{Log ($item.label+' 원본 화면 저장 실패: '+$_.Exception.Message)}
   break
  }catch{
   $errorParts=@();$errorObject=$_.Exception
   while($errorObject){$errorParts+=($errorObject.GetType().Name+': '+$errorObject.Message);$errorObject=$errorObject.InnerException}
   $detail=$errorParts -join ' -> '
   Log ($item.label+' 연결 오류 ('+$attempt+'/2): '+$detail)
   $quote=[pscustomobject]@{ok=$false;reason=$detail;source=$item.url}
  }
 }
 $at=[TimeZoneInfo]::ConvertTimeFromUtc([datetime]::UtcNow,$tz)
 $quote|Add-Member -NotePropertyName collectedAtKst -NotePropertyValue ($at.ToString('yyyy-MM-ddTHH:mm:ss')+'+09:00') -Force
 $quote|Add-Member -NotePropertyName label -NotePropertyValue $item.label -Force
 $quote|Add-Member -NotePropertyName key -NotePropertyValue $item.key -Force
 $rows+=,$quote
 if($quote.ok){Log ($item.label+': '+$quote.priceText+' / '+$quote.direction+' '+$quote.changeText+$quote.changeUnit)}else{$allOk=$false;Log ($item.label+' 확인 필요: '+$quote.reason)}
}
$result=@{mode=$(if($Scheduled){'scheduled_0700_collection_window'}else{'manual_current_time_test'});allParsed=$allOk;approvedForReport=$false;requestedReferenceTime=$(if($Scheduled){$now.ToString('yyyy-MM-dd')+'T07:00:00+09:00'}else{$null});items=$rows}
$result|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $folder 'financial_info.json') -Encoding UTF8
function ConvertTo-KepcoHtml($s){[System.Net.WebUtility]::HtmlEncode([string]$s)}
$html='<!doctype html><html lang="ko"><meta charset="utf-8"><title>주가·환율 수집 확인</title><style>body{font:16px "Malgun Gothic",sans-serif;margin:32px;max-width:1100px}table{border-collapse:collapse;width:100%}td,th{padding:12px;border:1px solid #ccc;text-align:left}.up{color:#d00000}.down{color:#0059d9}.flat{color:#222}pre{white-space:pre-wrap}small{color:#555}</style><h1>주가·환율 수집 확인</h1><p>수집값과 원본 화면을 대조하는 시험 결과입니다. 오전 7시 이후 수동 실행한 값은 오전 7시 자료가 아닙니다.</p><table><tr><th>항목</th><th>가격</th><th>전일 대비</th><th>실제 수집 시각</th></tr>'
foreach($r in $rows){
 if($r.ok){$symbol=switch($r.direction){up{'▲'}down{'▼'}default{'-'}};$html+='<tr><td>'+(ConvertTo-KepcoHtml $r.label)+'</td><td>'+(ConvertTo-KepcoHtml $r.priceText)+' '+(ConvertTo-KepcoHtml $r.currency)+'</td><td class="'+$r.direction+'">'+$symbol+(ConvertTo-KepcoHtml $r.changeText)+(ConvertTo-KepcoHtml $r.changeUnit)+'</td><td>'+(ConvertTo-KepcoHtml $r.collectedAtKst)+'</td></tr>'}
 else{$html+='<tr><td>'+(ConvertTo-KepcoHtml $r.label)+'</td><td colspan="3">확인 필요: '+(ConvertTo-KepcoHtml $r.reason)+'</td></tr>'}
}
$html+='</table><p>원본 화면 및 표시된 기준 시각</p>'
foreach($r in $rows){
 $html+='<details><summary>'+(ConvertTo-KepcoHtml $r.label)+'</summary><p>'+(ConvertTo-KepcoHtml $r.sourceTimeText)+'</p>'
 if(Test-Path -LiteralPath (Join-Path $folder ($r.key+'_원본화면.png'))){$html+='<p><a href="'+$r.key+'_원본화면.png">원본 화면 보기</a></p>'}
 if($r.key -eq 'fx' -and (Test-Path -LiteralPath (Join-Path $folder 'fx_네이버원본.json'))){$html+='<p><a href="fx_네이버원본.json">네이버 원본 데이터 보기</a></p>'}
 if($r.key -eq 'us' -and (Test-Path -LiteralPath (Join-Path $folder 'us_구글원본.html'))){$html+='<p>구글 원본 HTML 저장됨</p>'}
 $html+='<pre>'+(ConvertTo-KepcoHtml $r.evidence)+'</pre></details>'
}
[IO.File]::WriteAllText((Join-Path $folder '수집결과.html'),$html,[Text.UTF8Encoding]::new($true))
Log '주가·환율 확인용 수집결과.html 저장 완료. 값이 불명확한 항목은 보고서에 넣지 않습니다.'
