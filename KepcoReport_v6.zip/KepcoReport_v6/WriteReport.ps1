﻿param([Parameter(Mandatory=$true)][string]$ResultFolder)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
if(!('KepcoHwpStorage' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'HwpStorage.cs')}
function Expand-KepcoStream([byte[]]$Bytes){
 $m=[IO.MemoryStream]::new($Bytes,$false);$o=[IO.MemoryStream]::new()
 try{$z=[IO.Compression.DeflateStream]::new($m,[IO.Compression.CompressionMode]::Decompress);try{$z.CopyTo($o);return ,$o.ToArray()}finally{$z.Dispose()}}finally{$m.Dispose();$o.Dispose()}
}
function Compress-KepcoStream([byte[]]$Bytes){
 $m=[IO.MemoryStream]::new()
 try{$z=[IO.Compression.DeflateStream]::new($m,[IO.Compression.CompressionMode]::Compress,$true);try{$z.Write($Bytes,0,$Bytes.Length)}finally{$z.Dispose()};return ,$m.ToArray()}finally{$m.Dispose()}
}
function Set-KepcoBytes([byte[]]$Bytes,[int]$Offset,[byte[]]$Value){[Array]::Copy($Value,0,$Bytes,$Offset,$Value.Length)}
function Get-KepcoRecords([byte[]]$Bytes){
 $records=[Collections.Generic.List[object]]::new();$pos=0
 while($pos -lt $Bytes.Length){
  if($pos+4 -gt $Bytes.Length){throw '한글 레코드 헤더 손상'}
  $h=[BitConverter]::ToUInt32($Bytes,$pos);$pos+=4;$size=[int]($h -shr 20)
  if($size -eq 4095){$size=[int][BitConverter]::ToUInt32($Bytes,$pos);$pos+=4}
  if($size -lt 0 -or $pos+$size -gt $Bytes.Length){throw '한글 레코드 길이 오류'}
  $data=New-Object byte[] $size;[Array]::Copy($Bytes,$pos,$data,0,$size);$pos+=$size
  $records.Add([pscustomobject]@{Tag=([int]($h -band 1023));Level=([int](($h -shr 10) -band 1023));Data=$data})
 }
 return ,$records
}
function Join-KepcoRecords($Records){
 $m=[IO.MemoryStream]::new();$w=[IO.BinaryWriter]::new($m)
 try{foreach($r in $Records){$size=$r.Data.Length;$h=[uint32]($r.Tag -bor ($r.Level -shl 10));if($size -ge 4095){$h=$h -bor [uint32]4293918720;$w.Write($h);$w.Write([uint32]$size)}else{$h=$h -bor [uint32]([long]$size*1048576);$w.Write($h)};$w.Write([byte[]]$r.Data)};$w.Flush();return ,$m.ToArray()}finally{$w.Dispose();$m.Dispose()}
}
function Set-KepcoText($Records,[string]$Old,[string]$New,[int]$Shape=-1,[int]$RecordIndex=-1){
 $matches=@(for($i=0;$i -lt $Records.Count;$i++){if(($RecordIndex -lt 0 -or $i -eq $RecordIndex) -and $Records[$i].Tag -eq 67 -and [Text.Encoding]::Unicode.GetString($Records[$i].Data).Contains($Old)){$i}})
 if($matches.Count -ne 1){throw ('양식의 교체 대상이 유일하지 않습니다: '+$Old)}
 $i=$matches[0];$r=$Records[$i];$text=[Text.Encoding]::Unicode.GetString($r.Data)
 if($i -eq 0 -or $Records[$i-1].Tag -ne 66 -or $Records[$i-1].Level -ne $r.Level-1){throw '문단 구조 확인 실패'}
 $newText=$text.Replace($Old,$New);$r.Data=[Text.Encoding]::Unicode.GetBytes($newText)
 $header=$Records[$i-1].Data;$count=[BitConverter]::ToUInt32($header,0)
 $flags=$count -band [uint32]2147483648
 Set-KepcoBytes $header 0 ([BitConverter]::GetBytes([uint32]($flags -bor [uint32]$newText.Length)))
 # Keep original paragraph metrics; changed financial rows each occupy one line.
 for($j=$i+1;$j -lt $Records.Count -and $Records[$j].Level -ge $r.Level;$j++){
  if($Records[$j].Tag -eq 68 -and $Records[$j].Level -eq $r.Level){
   $oldShape=[BitConverter]::ToUInt32($Records[$j].Data,4);if($Shape -ge 0){$oldShape=[uint32]$Shape}
   $shapeData=New-Object byte[] 8;Set-KepcoBytes $shapeData 4 ([BitConverter]::GetBytes($oldShape));$Records[$j].Data=$shapeData
   Set-KepcoBytes $header 12 ([BitConverter]::GetBytes([uint16]1))
  }
 }
}
function Get-KepcoBmp([string]$ImagePath,[int]$Width,[int]$Height){
 $image=[Drawing.Image]::FromFile($ImagePath);$bmp=[Drawing.Bitmap]::new($Width,$Height);$g=[Drawing.Graphics]::FromImage($bmp);$m=[IO.MemoryStream]::new()
 try{$g.Clear([Drawing.Color]::White);$g.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $scale=[Math]::Min($Width/$image.Width,$Height/$image.Height);$w=[int][Math]::Round($image.Width*$scale);$h=[int][Math]::Round($image.Height*$scale)
  $g.DrawImage($image,[int](($Width-$w)/2),[int](($Height-$h)/2),$w,$h);$bmp.Save($m,[Drawing.Imaging.ImageFormat]::Bmp);return ,$m.ToArray()
 }finally{$image.Dispose();$g.Dispose();$bmp.Dispose();$m.Dispose()}
}
function Format-KepcoChange($Quote){$s=switch($Quote.direction){up{'▲'}down{'▼'}flat{'-'}default{throw '등락 방향 오류'}};return ($s+$Quote.changeText+$(if($Quote.key -eq 'us'){'%'}else{''}))}
function Get-KepcoChangeShape($Quote){switch($Quote.direction){up{return 37}down{return 6}flat{return 12}default{throw '등락 방향 오류'}}}
$metadata=Get-Content -LiteralPath (Join-Path $ResultFolder 'capture_info.json') -Raw -Encoding UTF8|ConvertFrom-Json
$finance=Get-Content -LiteralPath (Join-Path $ResultFolder 'financial_info.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(!$finance.allParsed -or @($finance.items).Count -ne 3){throw '주가·환율 3개가 모두 수집되어야 보고서를 생성합니다.'}
$domestic=@($finance.items|Where-Object {$_.key -eq 'domestic' -and $_.ok});$us=@($finance.items|Where-Object {$_.key -eq 'us' -and $_.ok});$fx=@($finance.items|Where-Object {$_.key -eq 'fx' -and $_.ok})
if($domestic.Count -ne 1 -or $us.Count -ne 1 -or $fx.Count -ne 1){throw '주가·환율 항목 검증 실패'}
$domestic=$domestic[0];$us=$us[0];$fx=$fx[0]
$energy=Get-Content -LiteralPath (Join-Path $ResultFolder 'energy_info.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(!$energy.allParsed -or @($energy.items).Count -ne 2){throw 'SMP·두바이유 수집이 완료되지 않았습니다. SMP_유가_수집결과.html을 확인해 주세요.'}
$smp=@($energy.items|Where-Object {$_.key -eq 'smp' -and $_.ok});$dubai=@($energy.items|Where-Object {$_.key -eq 'dubai' -and $_.ok})
if($smp.Count -ne 1 -or $dubai.Count -ne 1){throw 'SMP·유가 항목 검증 실패'}
$smp=$smp[0];$dubai=$dubai[0]
$generationDate=[TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([datetimeoffset]::UtcNow,'Korea Standard Time')
if($energy.reportDate -ne $generationDate.ToString('yyyy-MM-dd')){throw '자료 수집 중 날짜가 바뀌었습니다. 다시 실행해 주세요.'}
$cellDate=$generationDate.ToString('yyyy/MM/dd',[Globalization.CultureInfo]::InvariantCulture)
function Format-KepcoEnergyChange([decimal]$Value){if($Value -eq 0){return '(-0)'};$sym=if($Value -gt 0){'▲'}elseif($Value -lt 0){'▼'}else{'-'};return ('('+$sym+[Math]::Abs($Value).ToString('F2',[Globalization.CultureInfo]::InvariantCulture)+')')}
function Get-KepcoEnergyShape([decimal]$Value){if($Value -gt 0){return 38}elseif($Value -lt 0){return 23}else{return 44}}

$date=[datetimeoffset]::Parse($metadata.capturedAtKst);$dateLabel=$date.ToString('yyyy.MM.dd')+'('+@('일','월','화','수','목','금','토')[[int]$date.DayOfWeek]+')조간'
$scheduled=$metadata.mode -eq 'scheduled_0700'
$reference=if($scheduled){'(7시 현재)'}else{'('+$date.ToString('HH:mm')+' 현재)'}
$template=Join-Path $PSScriptRoot 'template.hwp'
$expected='C2481EE84DAC674555290B2944147BF62F1CA0357ED4B931A949062F87150106';$hash=(Get-FileHash -LiteralPath $template -Algorithm SHA256).Hash
if($hash -ne $expected){throw '기본 양식이 변경되었습니다. 제공된 template.hwp를 사용해 주세요.'}
$report=Join-Path $ResultFolder ('한전_주가지수_'+$date.ToString('yyyyMMdd_HHmmss')+'.hwp');$temp=$report+'.writing'
if(Test-Path -LiteralPath $report){throw '이미 같은 결과 파일이 있습니다.'}
Copy-Item -LiteralPath $template -Destination $temp
$store=$null
try{
 $store=[KepcoHwpStorage]::new($temp)
 $fileHeader=$store.Read('FileHeader');$flags=[BitConverter]::ToUInt32($fileHeader,36)
 if(($flags -band 1) -eq 0 -or ($flags -band 2) -ne 0){throw '압축 HWP5 양식인지 확인해 주세요.'}
 $body=Get-KepcoRecords (Expand-KepcoStream ($store.Read('BodyText/Section0')))
 $pairs=@(
  @('2026.10.23(금)조간',$dateLabel,-1),
  @('(Dubai)','(Dubai 선물)',-1),
  @('28,500원',($domestic.priceText+'원'),-1),
  @('▼350',(Format-KepcoChange $domestic),(Get-KepcoChangeShape $domestic)),
  @('10.72USD',($us.priceText+'USD'),-1),
  @('▲0.0050',(Format-KepcoChange $us),(Get-KepcoChangeShape $us)),
  @('1327.30',$fx.priceText,-1),
  @('▼0.20',(Format-KepcoChange $fx),(Get-KepcoChangeShape $fx)),
  @('(7시 현재)',$reference,-1)
 )
 $preview=[Text.Encoding]::Unicode.GetString($store.Read('PrvText'))
 foreach($pair in $pairs){Set-KepcoText $body $pair[0] $pair[1] $pair[2];$preview=$preview.Replace($pair[0],$pair[1])}
 # Target record indices are checked against the original template hash and expected text.
 # Duplicate date/price placeholders are addressed separately, so SMP and Dubai cannot be swapped.
 $energyCells=@(
  @(131,'2026/00/00',$cellDate,-1),
  @(136,'00.00',$smp.priceText,-1),
  @(141,'(▲00.00)',(Format-KepcoEnergyChange ([decimal]$smp.comparison.'2025')),(Get-KepcoEnergyShape ([decimal]$smp.comparison.'2025'))),
  @(147,'2026/00/00',$cellDate,-1),
  @(152,'00.00',$dubai.priceText,-1),
  @(157,'(▼00.00)',(Format-KepcoEnergyChange ([decimal]$dubai.comparison.'2025')),(Get-KepcoEnergyShape ([decimal]$dubai.comparison.'2025'))),
  @(204,'(▼15.6)',(Format-KepcoEnergyChange ([decimal]$smp.comparison.'2025')),(Get-KepcoEnergyShape ([decimal]$smp.comparison.'2025'))),
  @(219,'(▼10.22)',(Format-KepcoEnergyChange ([decimal]$dubai.comparison.'2025')),(Get-KepcoEnergyShape ([decimal]$dubai.comparison.'2025'))),
  @(243,'(▼38.67)',(Format-KepcoEnergyChange ([decimal]$smp.comparison.'2024')),(Get-KepcoEnergyShape ([decimal]$smp.comparison.'2024'))),
  @(258,'(▼2.52)',(Format-KepcoEnergyChange ([decimal]$dubai.comparison.'2024')),(Get-KepcoEnergyShape ([decimal]$dubai.comparison.'2024')))
 )
 foreach($cell in $energyCells){Set-KepcoText -Records $body -Old $cell[1] -New $cell[2] -Shape $cell[3] -RecordIndex $cell[0]}
 $preview=$preview.Replace('<2026/00/00><00.00><(▲00.00)>',('<'+$cellDate+'><'+$smp.priceText+'><'+(Format-KepcoEnergyChange ([decimal]$smp.comparison.'2025'))+'>'))
 $preview=$preview.Replace('<2026/00/00><00.00><(▼00.00)>',('<'+$cellDate+'><'+$dubai.priceText+'><'+(Format-KepcoEnergyChange ([decimal]$dubai.comparison.'2025'))+'>'))
 foreach($cell in $energyCells){if($cell[0] -in @(204,219,243,258)){$preview=$preview.Replace($cell[1],$cell[2])}}
 $bodyBytes=Join-KepcoRecords $body
 $store.Write('BodyText/Section0',(Compress-KepcoStream $bodyBytes))
 $store.Write('PrvText',[Text.Encoding]::Unicode.GetBytes($preview))
 $store.Write('BinData/BIN0001.bmp',(Compress-KepcoStream (Get-KepcoBmp (Join-Path $ResultFolder '코스피.png') 254 70)))
 $store.Write('BinData/BIN0002.bmp',(Compress-KepcoStream (Get-KepcoBmp (Join-Path $ResultFolder '코스닥.png') 218 66)))
 $store.RemovePreview();$store.Commit()
 $back=Expand-KepcoStream ($store.Read('BodyText/Section0'))
 if([Convert]::ToBase64String($back) -ne [Convert]::ToBase64String($bodyBytes)){throw '한글 저장 후 본문 검증 실패'}
 $store.Dispose();$store=$null
 Move-Item -LiteralPath $temp -Destination $report
 $note=@{report=[IO.Path]::GetFileName($report);capturedAtKst=$metadata.capturedAtKst;mode=$metadata.mode;financial=$finance.items;energy=$energy;energyDateCells=$cellDate;oilInstrument='Naver DCBc1 futures';annualOilBaselineBasisVerified=$false;templateHash=$hash;scope='Report date, quote images and figures, SMP inland weighted average, Dubai price, generation date in both energy date cells, and differences against the template 2025/2024 averages. Article content retained.'}
 $note|ConvertTo-Json -Depth 14|Set-Content -LiteralPath (Join-Path $ResultFolder 'report_info.json') -Encoding UTF8
 Write-Host ('한글 저장 완료: '+$report)
}catch{if($store){$store.Dispose();$store=$null};if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force};throw}
finally{if($store){$store.Dispose()}}
