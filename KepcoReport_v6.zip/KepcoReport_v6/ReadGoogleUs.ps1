﻿function ConvertFrom-KepcoGoogleQuote {
 param([string]$RawHtml)
 $text=[regex]::Replace($RawHtml,'(?is)<head\b[^>]*>.*?</head>',' ')
 $text=[regex]::Replace($text,'(?is)<(script|style|noscript)\b[^>]*>.*?</\1>',' ')
 $text=[regex]::Replace($text,'(?s)<[^>]+>',"`n")
 $text=[System.Net.WebUtility]::HtmlDecode($text).Replace([char]0x2212,'-')
 $text=[regex]::Replace($text,'\s+',' ').Trim()
 if($text -notmatch 'KEP\s*:\s*NYSE'){throw '구글 응답에서 KEP:NYSE 종목을 확인하지 못했습니다'}
 $heading=[regex]::Match($text,'Korea\s+Electric\s+Power\s+Corp(?:oration)?\b')
 if(!$heading.Success){throw '구글 응답에서 한국전력 회사명을 확인하지 못했습니다'}
 $start=$heading.Index+$heading.Length
 $block=$text.Substring($start,[Math]::Min(2000,$text.Length-$start))
 $priceMatch=[regex]::Match($block,'^\s*\$\s*(?<price>\d[\d,]*(?:\.\d+)?)')
 if(!$priceMatch.Success){throw '회사명 바로 다음의 정규장 가격을 구분하지 못했습니다'}
 $tail=$block.Substring($priceMatch.Length)
 # Only inspect the first quote. The next dollar amount may be after-hours.
 $boundary=[regex]::Match($tail,'\$|After\s*hours|Pre[- ]?market|Closed:|Open:|area_chart')
 if($boundary.Success){$tail=$tail.Substring(0,$boundary.Index)}
 if($tail.Length -gt 240){$tail=$tail.Substring(0,240)}
 $changeMatch=[regex]::Match($tail,'(?<sign>[+-]?)(?<percent>\d+(?:\.\d+)?)\s*%')
 if(!$changeMatch.Success){throw '정규장 가격의 등락률을 찾지 못했습니다'}
 $sign=$changeMatch.Groups['sign'].Value
 $arrow=[regex]::Match($tail,'arrow_(upward|downward)').Value
 $absolute=[regex]::Match($tail,'\(\s*(?<sign>[+-])\s*\d')
 if(!$sign -and $arrow){$sign=if($arrow -eq 'arrow_downward'){'-'}else{'+'}}
 if(!$sign -and $absolute.Success){$sign=$absolute.Groups['sign'].Value}
 $invariant=[Globalization.CultureInfo]::InvariantCulture
 $price=[double]::Parse($priceMatch.Groups['price'].Value.Replace(',',''),$invariant)
 $percent=[double]::Parse($changeMatch.Groups['percent'].Value,$invariant)
 if(!$sign -and $percent -ne 0){throw '미국 주가 등락 방향을 확인하지 못했습니다'}
 if($price -le 0 -or $price -gt 10000 -or $percent -gt 1000){throw '미국 주가 숫자 범위 확인 필요'}
 if(($sign -eq '+' -and $arrow -eq 'arrow_downward') -or ($sign -eq '-' -and $arrow -eq 'arrow_upward')){throw '미국 주가 부호와 방향 불일치'}
 $direction=if($percent -eq 0){'flat'}elseif($sign -eq '-'){'down'}else{'up'}
 $time=[regex]::Match($block,'Closed:\s*.{0,120}?\bUSD\b')
 return [pscustomobject]@{ok=$true;price=$price;priceText=$priceMatch.Groups['price'].Value;change=$percent;changeText=$changeMatch.Groups['percent'].Value;direction=$direction;changeUnit='%';currency='USD';source='https://www.google.com/finance/quote/KEP:NYSE?hl=en';pageTitle='Google Finance KEP:NYSE 정규장';sourceTimeText=$(if($time.Success){$time.Value}else{'페이지 기준 시각 확인 필요'});evidence=('Korea Electric Power Corp '+$block);sourceResponseFile='us_구글원본.html'}
}
function Read-KepcoGoogleUs {
 param([string]$OutputFolder)
 $url='https://www.google.com/finance/quote/KEP:NYSE?hl=en'
 $savedProtocol=[Net.ServicePointManager]::SecurityProtocol
 try{
  [Net.ServicePointManager]::SecurityProtocol=$savedProtocol -bor [Net.SecurityProtocolType]::Tls12
  $r=Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 25 -Headers @{Accept='text/html';'Accept-Language'='en-US,en;q=0.9'}
  $raw=[string]$r.Content
  [IO.File]::WriteAllText((Join-Path $OutputFolder 'us_구글원본.html'),$raw,[Text.UTF8Encoding]::new($true))
  return (ConvertFrom-KepcoGoogleQuote -RawHtml $raw)
 }finally{[Net.ServicePointManager]::SecurityProtocol=$savedProtocol}
}
