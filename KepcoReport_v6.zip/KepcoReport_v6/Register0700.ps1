﻿$ErrorActionPreference='Stop'
try{
 if([TimeZoneInfo]::Local.Id -ne 'Korea Standard Time'){throw 'Windows 시간대를 서울(UTC+09:00)로 설정한 뒤 등록해 주세요.'}
 $name='KEPCO_IndexCapture_0700';if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){throw '동일한 예약 작업이 이미 있습니다. 작업 스케줄러에서 확인하세요.'}
 $script=Join-Path $PSScriptRoot 'Capture.ps1';$taskArgs='-NoProfile -ExecutionPolicy Bypass -File "'+$script+'" -Scheduled'
 $act=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument $taskArgs -WorkingDirectory $PSScriptRoot
 $tr=New-ScheduledTaskTrigger -Daily -At '07:00';$st=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -WakeToRun -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
 $pr=New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
 Register-ScheduledTask -TaskName $name -Action $act -Trigger $tr -Settings $st -Principal $pr|Out-Null
 Write-Host '등록 완료: 매일 한국 시간 07:00. 전원 및 Windows 로그인이 필요합니다. 지나간 07:00 자료를 나중 값으로 대체 수집하지 않습니다.'
}catch{Write-Host ('등록 실패: '+$_.Exception.Message);exit 1}
