﻿param([Parameter(Mandatory=$true)][string]$ResultFolder,[Parameter(Mandatory=$true)][string]$ReportDate)
$ErrorActionPreference='Stop'
$inv=[Globalization.CultureInfo]::InvariantCulture
$targetDate=[datetime]::ParseExact($ReportDate,'yyyy-MM-dd',$inv)
function ConvertTo-KepcoPlain([string]$Html){
 $s=[regex]::Replace($Html,'(?is)<(script|style)\b[^>]*>.*?</\1>',' ')
 $s=[regex]::Replace($s,'(?s)<[^>]+>',' ')
 return ([regex]::Replace([Net.WebUtility]::HtmlDecode($s),'\s+',' ')).Trim()
}
function Get-KepcoTableRows([string]$Html){
 $list=[Collections.Generic.List[object]]::new()
 foreach($tr in [regex]::Matches($Html,'(?is)<tr\b[^>]*>(.*?)</tr>')){
  $cells=@(foreach($cell in [regex]::Matches($tr.Groups[1].Value,'(?is)<t[dh]\b[^>]*>(.*?)</t[dh]>')){ConvertTo-KepcoPlain $cell.Groups[1].Value})
  if($cells.Count){$list.Add([pscustomobject]@{cells=$cells})}
 }
 return ,$list
}
function Read-KepcoSmpHtml([string]$Html,[datetime]$Date){
 $plain=ConvertTo-KepcoPlain $Html
 if($plain -notmatch '육지' -or $plain -notmatch '원\s*/\s*kWh'){throw '육지 SMP 페이지 및 단위 확인 실패'}
 $anchor=[regex]::Match($plain,'(?<y>\d{4})년\s*(?<m>\d{1,2})월\s*(?<d>\d{1,2})일\s*거래분')
 if(!$anchor.Success){throw 'SMP 거래분 날짜를 찾지 못했습니다'}
 $anchorDate=[datetime]::new([int]$anchor.Groups['y'].Value,[int]$anchor.Groups['m'].Value,[int]$anchor.Groups['d'].Value)
 $candidates=@()
 foreach($table in [regex]::Matches($Html,'(?is)<table\b[^>]*>.*?</table>')){
  $rows=Get-KepcoTableRows $table.Value
  $weighted=@($rows|Where-Object {($_.cells[0] -replace '\s','') -match '^가중평균(?:SMP)?$'})
  if($weighted.Count -ne 1){continue}
  $values=$weighted[0].cells
  foreach($row in $rows){
   if($row.cells.Count -ne $values.Count){continue}
   $headerLabel=($row.cells[0] -replace '\s','')
   $isDateHeader=$headerLabel -match '^(구분|날짜|일자|시간)$'
   if(!$isDateHeader){continue}
   for($i=1;$i -lt $row.cells.Count;$i++){
    $dm=[regex]::Match($row.cells[$i],'^\s*(?<m>\d{1,2})\s*[./]\s*(?<d>\d{1,2})\s*(?:\([가-힣]\))?\s*$')
    if(!$dm.Success){continue}
    $year=$anchorDate.Year;$month=[int]$dm.Groups['m'].Value;$day=[int]$dm.Groups['d'].Value
    if($month -gt $anchorDate.Month+6){$year--}elseif($month -lt $anchorDate.Month-6){$year++}
    $dayDate=[datetime]::MinValue
    $dateText='{0:D4}-{1:D2}-{2:D2}' -f $year,$month,$day
    if(![datetime]::TryParseExact($dateText,'yyyy-MM-dd',$inv,[Globalization.DateTimeStyles]::None,[ref]$dayDate)){continue}
    $number=$values[$i] -replace ',',''
    if($dayDate -gt $Date -or $dayDate -lt $Date.AddDays(-7) -or $number -notmatch '^\d+(?:\.\d+)?$'){continue}
    $price=[decimal]::Parse($number,$inv)
    if($price -le 0 -or $price -gt 10000){continue}
    $candidates+=[pscustomobject]@{date=$dayDate;price=$price}
   }
  }
 }
 $latest=@($candidates|Sort-Object date -Descending)
 if(!$latest.Count){throw 'SMP 날짜 열과 가중평균 값을 연결하지 못했습니다'}
 $best=$latest[0];$same=@($latest|Where-Object {$_.date -eq $best.date}|Select-Object -ExpandProperty price -Unique)
 if($same.Count -ne 1){throw '같은 날짜의 육지 SMP 값이 여러 개입니다'}
 return [pscustomobject]@{ok=$true;key='smp';label='SMP(육지 가중평균)';price=$best.price;priceText=$best.price.ToString('F2',$inv);unit='원/kWh';sourceDate=$best.date.ToString('yyyy-MM-dd');isPriorDate=($best.date -ne $Date);source='https://kpx.or.kr/smpInland.es?mid=a30301000000';evidence=('거래분 '+$anchorDate.ToString('yyyy-MM-dd')+' / 날짜 열 '+$best.date.ToString('yyyy-MM-dd')+' / 가중평균 '+$best.price);rawFile='smp_전력거래소원본.html'}
}
function ConvertFrom-KepcoDubaiFutures($Data,[datetime]$Date){
 $options=@($Data.energyInfo,$Data.marketIndexInfo,$Data.result,$Data)
 $valid=@($options|Where-Object {$_ -and $_.reutersCode -eq 'DCBc1' -and $_.name -match '두바이|Dubai' -and $_.closePrice})
 if($valid.Count -ne 1){throw '네이버 두바이유 DCBc1 항목을 유일하게 확인하지 못했습니다'}
 $q=$valid[0]
 if(([string]$q.nameEng+' '+[string]$q.description) -notmatch 'Futures|선물'){throw '두바이유 선물 상품인지 확인하지 못했습니다'}
 if([string]$q.unit -notmatch '^USD\s*/\s*(?:BBL|barrel)$'){throw '두바이유 달러/배럴 단위 검증 실패'}
 $text=([string]$q.closePrice).Replace(',','')
 if($text -notmatch '^\d+(?:\.\d+)?$'){throw '두바이유 가격 형식 검증 실패'}
 $price=[decimal]::Parse($text,$inv)
 $tradedAt=[datetimeoffset]::Parse([string]$q.localTradedAt,$inv)
 $tradedKst=[TimeZoneInfo]::ConvertTimeBySystemTimeZoneId($tradedAt,'Korea Standard Time')
 if($price -le 0 -or $price -gt 1000 -or $tradedAt.UtcDateTime -gt [datetime]::UtcNow.AddMinutes(2) -or $tradedKst.Date -lt $Date.AddDays(-10)){throw '두바이유 가격 또는 실제 시세 기준 시각 확인 필요'}
 return [pscustomobject]@{ok=$true;key='dubai';label='두바이유(Dubai 선물)';price=$price;priceText=$price.ToString('F2',$inv);unit='USD/bbl';sourceDate=$tradedAt.ToString('yyyy-MM-dd');sourceTimeText=[string]$q.localTradedAt;sourceTimeKst=$tradedKst.ToString('o');contractMonth=[string]$q.month;instrumentType='futures';instrumentCode='DCBc1';isPriorDate=($tradedKst.Date -ne $Date);source='https://api.stock.naver.com/marketindex/energy/DCBc1';evidence=($q|ConvertTo-Json -Depth 12);rawFile='dubai_네이버선물원본.json';annualBaselineBasisVerified=$false}
}
function Read-KepcoDubaiFutures {
 $url='https://api.stock.naver.com/marketindex/energy/DCBc1'
 $r=Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 20 -Headers @{Accept='application/json';Referer='https://stock.naver.com/'}
 $raw=[string]$r.Content
 [IO.File]::WriteAllText((Join-Path $ResultFolder 'dubai_네이버선물원본.json'),$raw,[Text.UTF8Encoding]::new($true))
 return (ConvertFrom-KepcoDubaiFutures ($raw|ConvertFrom-Json) $targetDate)
}
$savedProtocol=[Net.ServicePointManager]::SecurityProtocol
$items=@()
try{
 [Net.ServicePointManager]::SecurityProtocol=$savedProtocol -bor [Net.SecurityProtocolType]::Tls12
 Write-Host 'SMP 육지 가중평균 수집 시작'
 try{
  $r=Invoke-WebRequest -Uri 'https://kpx.or.kr/smpInland.es?mid=a30301000000' -UseBasicParsing -TimeoutSec 25
  $raw=[string]$r.Content;[IO.File]::WriteAllText((Join-Path $ResultFolder 'smp_전력거래소원본.html'),$raw,[Text.UTF8Encoding]::new($true))
  $q=Read-KepcoSmpHtml $raw $targetDate
 }catch{$q=[pscustomobject]@{ok=$false;key='smp';label='SMP(육지 가중평균)';reason=$_.Exception.Message}}
 $q|Add-Member -NotePropertyName collectedAtKst -NotePropertyValue ([TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([datetimeoffset]::UtcNow,'Korea Standard Time').ToString('o'))
 $items+=,$q
 Write-Host '두바이유 수집 시작 [V6: 네이버 DCBc1 선물]'
 try{$q=Read-KepcoDubaiFutures}
 catch{$q=[pscustomobject]@{ok=$false;key='dubai';label='두바이유(Dubai 선물)';reason=$_.Exception.Message}}
 $q|Add-Member -NotePropertyName collectedAtKst -NotePropertyValue ([TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([datetimeoffset]::UtcNow,'Korea Standard Time').ToString('o'))
 $items+=,$q
}finally{[Net.ServicePointManager]::SecurityProtocol=$savedProtocol}
# The annual averages below are the user's template values, not newly fetched annual statistics.
$baseline=@{smp=@{'2025'=[decimal]112.73;'2024'=[decimal]128.33};dubai=@{'2025'=[decimal]69.36;'2024'=[decimal]79.58}}
foreach($q in $items){
 if($q.ok){
  $comparison=@{}
  foreach($year in @('2025','2024')){$comparison[$year]=[Math]::Round(([decimal]$q.price-$baseline[$q.key][$year]),2,[MidpointRounding]::AwayFromZero)}
  $q|Add-Member -NotePropertyName comparison -NotePropertyValue $comparison
  Write-Host ($q.label+': '+$q.priceText+' '+$q.unit+' / 자료일 '+$q.sourceDate+' / 2025 대비 '+$comparison['2025']+' / 2024 대비 '+$comparison['2024'])
 }else{Write-Host ($q.label+' 확인 필요: '+$q.reason)}
}
$result=@{annualOilBaselineBasisVerified=$false;annualOilBaselineNote='Template 2025/2024 means retained; matching futures basis not verified';buildVersion='V6-NAVER-DUBAI-FUTURES-20261103';reportDate=$ReportDate;allParsed=(@($items|Where-Object {!$_.ok}).Count -eq 0);dateCellPolicy='report_generation_date';baselines=$baseline;items=$items}
$result|ConvertTo-Json -Depth 14|Set-Content -LiteralPath (Join-Path $ResultFolder 'energy_info.json') -Encoding UTF8
function ConvertTo-KepcoEnergyHtml($s){[Net.WebUtility]::HtmlEncode([string]$s)}
$html='<!doctype html><html lang="ko"><meta charset="utf-8"><title>SMP·두바이유 수집 확인</title><style>body{font:16px "Malgun Gothic",sans-serif;margin:32px}td,th{padding:12px;border:1px solid #bbb}table{border-collapse:collapse}.up{color:red}.down{color:blue}pre{white-space:pre-wrap}</style><h1>SMP·두바이유 수집 확인</h1><p>보고서 날짜 칸: '+$targetDate.ToString('yyyy/MM/dd',[Globalization.CultureInfo]::InvariantCulture)+'</p><table><tr><th>항목</th><th>수집값</th><th>실제 자료 날짜</th><th>2025 평균 대비</th><th>2024 평균 대비</th></tr>'
foreach($q in $items){
 $html+='<tr><td>'+(ConvertTo-KepcoEnergyHtml $q.label)+'</td>'
 if($q.ok){$html+='<td>'+$q.priceText+' '+$q.unit+'</td><td>'+$q.sourceDate+'</td>';foreach($year in @('2025','2024')){$v=[decimal]$q.comparison[$year];$cls=if($v -gt 0){'up'}elseif($v -lt 0){'down'}else{'flat'};$sym=if($v -gt 0){'▲'}elseif($v -lt 0){'▼'}else{'-'};$html+='<td class="'+$cls+'">'+$sym+[Math]::Abs($v).ToString('F2',$inv)+'</td>'}}
 else{$html+='<td colspan="4">확인 필요: '+(ConvertTo-KepcoEnergyHtml $q.reason)+'</td>'};$html+='</tr>'
}
$html+='</table><p>유가는 네이버 두바이유 선물 DCBc1입니다. 연평균 기준값은 양식의 기존 숫자를 유지했으며 같은 선물 기준인지는 아직 확인되지 않았습니다.</p><p>비교 기준은 제공된 한글 양식의 연평균 값입니다. 각 차이는 당일 수집값에서 해당 평균가를 뺀 금액이며 퍼센트가 아닙니다. 수동 실행은 실행 당시 공개 자료를 사용합니다.</p>'
foreach($q in $items){$html+='<details><summary>'+(ConvertTo-KepcoEnergyHtml $q.label)+'</summary><p>실제 수집: '+(ConvertTo-KepcoEnergyHtml $q.collectedAtKst)+'</p><p>시세 기준 시각: '+(ConvertTo-KepcoEnergyHtml $q.sourceTimeText)+' / 한국 시각: '+(ConvertTo-KepcoEnergyHtml $q.sourceTimeKst)+'</p><pre>'+(ConvertTo-KepcoEnergyHtml $q.evidence)+'</pre></details>'}
[IO.File]::WriteAllText((Join-Path $ResultFolder 'SMP_유가_수집결과.html'),$html,[Text.UTF8Encoding]::new($true))
