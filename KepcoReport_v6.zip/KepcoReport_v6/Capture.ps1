﻿param([switch]$Scheduled,[switch]$Financial,[switch]$Report,[switch]$Energy,[string]$TestUrl='',[switch]$KeepBrowser)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot;$tz=[TimeZoneInfo]::FindSystemTimeZoneById('Korea Standard Time');$now=[TimeZoneInfo]::ConvertTimeFromUtc([datetime]::UtcNow,$tz)
if($Scheduled -and ($now.Hour -ne 7 -or $now.Minute -ne 0)){Write-Host '07:00 예약 수집 시간이 아니므로 현재 화면으로 대체하지 않습니다.';exit 2}
$url='https://search.daum.net/search?w=tot&q=%EC%A3%BC%EA%B0%80';if($TestUrl){$url=$TestUrl}
$folder=Join-Path $root ('result\'+$now.ToString('yyyy-MM-dd')+'\'+$now.ToString('HHmmss'));New-Item -ItemType Directory -Force -Path $folder|Out-Null
$log=Join-Path $folder 'capture.log'
function Log($s){$line='[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'),$s;Write-Host $line;Add-Content -LiteralPath $log -Value $line -Encoding UTF8}
$browserPath=@("$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe","${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe","$env:ProgramFiles\Google\Chrome\Application\chrome.exe","${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe","$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")|Where-Object {Test-Path -LiteralPath $_}|Select-Object -First 1
$captureProfile=Join-Path ([IO.Path]::GetTempPath()) ('KepcoCapture_'+[guid]::NewGuid().ToString('N'))
$socket=$null;$proc=$null;$script:CdpId=0;$success=$false
function CDP([string]$method,$parameters=@{}){
 $script:CdpId++;$id=$script:CdpId;$json=@{id=$id;method=$method;params=$parameters}|ConvertTo-Json -Depth 40 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($json);$token=[Threading.CancellationTokenSource]::new(25000)
 try{
  [void]$socket.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,$token.Token).GetAwaiter().GetResult()
  while($true){$memory=[IO.MemoryStream]::new();try{
   do{$buffer=New-Object byte[] 65536;$part=$socket.ReceiveAsync([ArraySegment[byte]]::new($buffer),$token.Token).GetAwaiter().GetResult();if($part.MessageType -eq [Net.WebSockets.WebSocketMessageType]::Close){throw '브라우저 연결이 종료됐습니다.'};$memory.Write($buffer,0,$part.Count)}while(!$part.EndOfMessage)
   $reply=[Text.Encoding]::UTF8.GetString($memory.ToArray())|ConvertFrom-Json
  }finally{$memory.Dispose()}
  if($reply.id -eq $id){if($reply.error){throw ($method+': '+($reply.error|ConvertTo-Json -Compress))};return $reply.result}
  }
 }finally{$token.Dispose()}
}
function Eval([string]$expression){$r=CDP 'Runtime.evaluate' @{expression=$expression;returnByValue=$true};if($r.exceptionDetails){throw ('페이지 검사 오류: '+($r.exceptionDetails|ConvertTo-Json -Depth 10 -Compress))};return $r.result.value}
function Capture([string]$path,$rect){$params=@{format='png';captureBeyondViewport=$true;fromSurface=$true};if($rect){$params.clip=@{x=[double]$rect.x;y=[double]$rect.y;width=[double]$rect.width;height=[double]$rect.height;scale=1}};$r=CDP 'Page.captureScreenshot' $params;[IO.File]::WriteAllBytes($path,[Convert]::FromBase64String($r.data))}
try{
 Log '프로그램 버전: V6-NAVER-DUBAI-FUTURES-20261103'
 if(!$browserPath){throw 'Microsoft Edge 또는 Chrome을 찾지 못했습니다.'}
 Log ('브라우저: '+$browserPath);Log ('시험 시작(KST): '+$now.ToString('yyyy-MM-dd HH:mm:ss'));Log ('요청 URL: '+$url)
 $psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName=$browserPath;$psi.Arguments='--remote-debugging-address=127.0.0.1 --remote-debugging-port=0 --user-data-dir="'+$captureProfile+'" --no-first-run --no-default-browser-check --new-window --window-size=1440,1000 about:blank';$psi.UseShellExecute=$false
 $proc=[Diagnostics.Process]::Start($psi);$portFile=Join-Path $captureProfile 'DevToolsActivePort';$deadline=[datetime]::UtcNow.AddSeconds(25)
 while(!(Test-Path -LiteralPath $portFile)){if([datetime]::UtcNow -gt $deadline){throw '브라우저 진단 연결 준비 시간 초과'};Start-Sleep -Milliseconds 200}
 $port=(Get-Content -LiteralPath $portFile)[0];$tabs=Invoke-RestMethod -Uri ('http://127.0.0.1:'+$port+'/json/list') -TimeoutSec 10;$target=$tabs|Where-Object {$_.type -eq 'page'}|Select-Object -First 1;if(!$target){throw '캡처할 브라우저 탭을 찾지 못했습니다.'}
 $socket=[Net.WebSockets.ClientWebSocket]::new();$socket.Options.Proxy=$null;$cts=[Threading.CancellationTokenSource]::new(10000);try{[void]$socket.ConnectAsync([uri]$target.webSocketDebuggerUrl,$cts.Token).GetAwaiter().GetResult()}finally{$cts.Dispose()}
 [void](CDP 'Page.enable');[void](CDP 'Runtime.enable');[void](CDP 'Emulation.setDeviceMetricsOverride' @{width=1440;height=1000;deviceScaleFactor=1;mobile=$false})
 $nav=CDP 'Page.navigate' @{url=$url};if($nav.errorText){throw ('페이지 접속 실패: '+$nav.errorText)}
 $locate=[IO.File]::ReadAllText((Join-Path $root 'locate.js'),[Text.Encoding]::UTF8);$deadline=[datetime]::UtcNow.AddSeconds(35);$found=$null
 while([datetime]::UtcNow -lt $deadline){$found=Eval $locate;if($found.ok){break};if($found.reason -match '접근 확인 또는 차단'){throw $found.reason};Start-Sleep -Seconds 1}
 if(!$found.ok){
  Capture (Join-Path $folder '진단_전체화면.png') $null
  $found|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $folder 'diagnostic.json') -Encoding UTF8
  throw '코스피/코스닥 영역 확인 실패. 진단_전체화면.png와 capture.log를 확인해 주세요.'
 }
 # Two observations prevent capture during a DOM position/value transition.
 Start-Sleep -Milliseconds 600;$again=Eval $locate;if(!$again.ok){throw '캡처 직전 지수 영역이 사라졌습니다.'}
 $found=$again;Log ('코스피: '+$found.kospi.text);Log ('코스닥: '+$found.kosdaq.text)
 $kospi=Join-Path $folder '코스피.png';$kosdaq=Join-Path $folder '코스닥.png';Capture $kospi $found.kospi;Capture $kosdaq $found.kosdaq
 $combined=Join-Path $folder '코스피_코스닥.png'
 if($found.sameRow -and $found.union.width -lt 1100 -and $found.union.height -lt 500){Capture $combined $found.union}
 else{
  Add-Type -AssemblyName System.Drawing;$a=[Drawing.Image]::FromFile($kospi);$b=[Drawing.Image]::FromFile($kosdaq)
  try{$w=$a.Width+$b.Width+12;$h=[Math]::Max($a.Height,$b.Height);$bmp=[Drawing.Bitmap]::new($w,$h);$g=[Drawing.Graphics]::FromImage($bmp);try{$g.Clear([Drawing.Color]::White);$g.DrawImage($a,0,0,$a.Width,$a.Height);$g.DrawImage($b,$a.Width+12,0,$b.Width,$b.Height);$bmp.Save($combined,[Drawing.Imaging.ImageFormat]::Png)}finally{$g.Dispose();$bmp.Dispose()}}finally{$a.Dispose();$b.Dispose()}
 }
 $captured=[TimeZoneInfo]::ConvertTimeFromUtc([datetime]::UtcNow,$tz);$metadata=@{mode=$(if($Scheduled){'scheduled_0700'}else{'manual_current_time_test'});requestedDate=$now.ToString('yyyy-MM-dd');requestedReferenceTime=$(if($Scheduled){'07:00:00+09:00'}else{$null});capturedAtKst=($captured.ToString('yyyy-MM-ddTHH:mm:ss')+'+09:00');source=$found.pageUrl;pageTitle=$found.pageTitle;kospi=$found.kospi;kosdaq=$found.kosdaq;combinedFile='코스피_코스닥.png';needsVisualCheck=$true}
 $metadata|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $folder 'capture_info.json') -Encoding UTF8
 if($Financial -or $Report){. (Join-Path $root 'CollectFinance.ps1')}
 if($Energy -or $Report){& (Join-Path $root 'CollectEnergy.ps1') -ResultFolder $folder -ReportDate ($now.ToString('yyyy-MM-dd'))}
 if($Report){& (Join-Path $root 'WriteReport.ps1') -ResultFolder $folder}
 Log ('저장 완료: '+$combined);Log ('실제 캡처 시각(KST): '+$captured.ToString('yyyy-MM-dd HH:mm:ss'));if($Report){Log '한글 보고서 저장 완료. 생성된 HWP를 열어 배치와 색상을 확인해 주세요.'}else{Log '내용과 영역이 맞는지 PNG를 확인해 주세요. 아직 한글 파일에는 삽입하지 않았습니다.'};$success=$true
 if(!$Scheduled){Start-Process -FilePath explorer.exe -ArgumentList ('"'+$folder+'"')}
}catch{Log ('실패: '+$_.Exception.Message);Log ('위치: '+$_.ScriptStackTrace)}
finally{
 if($socket -and $socket.State -eq [Net.WebSockets.WebSocketState]::Open -and !$KeepBrowser){try{[void](CDP 'Browser.close')}catch{}}
 if($socket){$socket.Dispose()}
 # Isolated temporary profile is retained for diagnostics; existing browser profiles are never used.
}
if(!$success){exit 1}
